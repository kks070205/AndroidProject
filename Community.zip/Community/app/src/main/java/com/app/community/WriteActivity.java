package com.app.community;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.app.community.server.HTTPAsuncTask;

import java.util.concurrent.ExecutionException;

public class WriteActivity extends Activity {



    HTTPAsuncTask task;

    //위젯 변수 선언
    EditText edtTile_write, edtContents_write;
    Button btnWriteOK_write, btnUpdateOK_write;
    Intent data;
    String mSelectCategory, action;
    Spinner spnCategory_write;

    @Override
    public void startActivityForResult(Intent intent, int requestCode) {
        super.startActivityForResult(intent, requestCode);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_write);

        edtTile_write = (EditText) findViewById(R.id.edtTile_write);
        edtContents_write = (EditText) findViewById(R.id.edtContents_write);
        btnWriteOK_write = (Button) findViewById(R.id.btnWriteOK_write);
        btnUpdateOK_write = (Button) findViewById(R.id.btnUpdateOK_write);

        data = getIntent();
        action = data.getStringExtra("action");
        //전 액티비티에서 수정 버튼을 눌렀을 경우, 수정 전용 버튼 visible
        if (action.equals("update")) {
            btnWriteOK_write.setVisibility(View.GONE);
            btnUpdateOK_write.setVisibility(View.VISIBLE);

            //전 액티비티 내용들 EditView에 설정
            edtTile_write.setText(data.getStringExtra("title"));
            edtContents_write.setText(data.getStringExtra("contents"));

        } else if (action.equals("insert")) {
            btnWriteOK_write.setVisibility(View.VISIBLE);
            btnUpdateOK_write.setVisibility(View.GONE);
        }

        //작성 완료 버튼 터치 시
        btnWriteOK_write.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mSelectCategory = spnCategory_write.getSelectedItem().toString();
                String sort = data.getStringExtra("sort");

                //입력한 정보들을 서버에 insert 요청
                Bundle bundle = new Bundle();
                bundle.putSerializable("action", action);
                bundle.putSerializable("sort", sort);
                bundle.putSerializable("userid", getSharedPreferences("info", MODE_PRIVATE).getString("userid", ""));
                bundle.putSerializable("title", edtTile_write.getText().toString());
                bundle.putSerializable("contents", edtContents_write.getText().toString());
                task = new HTTPAsuncTask(getApplicationContext(), bundle);

                try {
                    //서버에서 받은 값
                    if (task.execute("").get().trim().equals("1")) {
                        //1일 경우
                        //insert 성공 시
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                    } else {
                        //insert 실패 시
                        Toast.makeText(getApplicationContext(), "작성 실패했습니다. 다시 확인해주세요.", Toast.LENGTH_LONG);
                    }

                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }
            }
        });

        //수정 완료 버튼 터치시
        btnUpdateOK_write.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mSelectCategory = spnCategory_write.getSelectedItem().toString();
                String sort = data.getStringExtra("sort");

                //입력한 정보들을 서버에 insert 요청
                Bundle bundle = new Bundle();
                bundle.putSerializable("action", action);
                bundle.putSerializable("sort", sort);
                bundle.putSerializable("userid", getSharedPreferences("info", MODE_PRIVATE).getString("userid", ""));
                bundle.putSerializable("title", edtTile_write.getText().toString());
                bundle.putSerializable("contents", edtContents_write.getText().toString());
                bundle.putSerializable("regnum", data.getIntExtra("regnum", 0));

                task = new HTTPAsuncTask(getApplicationContext(), bundle);

                try {
                    //서버에서 받은 값
                    if (task.execute("").get().trim().equals("1")) {
                        //insert 성공 시
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                    } else {
                        //insert 실패 시
                        Toast.makeText(getApplicationContext(), "작성 실패했습니다. 다시 확인해주세요.", Toast.LENGTH_LONG);
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }
            }
        });
    }



    @Override
    protected void onPause() {
        super.onPause();
        if (task != null) {
            task.cancel(true);
            task = null;
        }
    }

}
