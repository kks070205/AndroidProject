package com.app.community.ListView;

/**
 * Created by kks6258 on 2017-04-07.
 */
//@SuppressWarnings("serial"), implements Serializable
public class DataObject {
    private String username;  //사용자 아이디
    private int regnum;    //등록번호
    private String regtime;  ////등록시간
    private String content;   //내용
    private String title;   //제목
    private String action;

    public String getUserid() {
        return username;
    }

    public void setUserid(String userid) {
        this.username = userid;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public int getRegnum() {
        return regnum;
    }

    public void setRegnum(int reg_num) {
        this.regnum = reg_num;
    }

    public String getRegtime() {
        return regtime;
    }

    public void setRegtime(String regtime) {
        this.regtime = regtime;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

}
