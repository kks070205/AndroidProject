package com.app.community;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.text.InputFilter;
import android.text.InputType;
import android.text.Spanned;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.app.community.server.HTTPAsuncTask;
import com.app.community.server.ServerConnect;

import java.util.concurrent.ExecutionException;
import java.util.regex.Pattern;

public class Membership extends Activity {

    //선언
    EditText edtMember_id, edtMember_pw, edtMember_pw_re,edtMember_email,edtMember_name;   //사용자 id, pw, pw확인, email, 이름
    Button btnMember_OK;        //회원가입 버튼
    HTTPAsuncTask task = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_membership);

        //결합
        edtMember_id = (EditText) findViewById(R.id.edtMember_id);
        edtMember_pw = (EditText) findViewById(R.id.edtMember_pw);
        edtMember_pw_re = (EditText) findViewById(R.id.edtMmber_pw_re);
        edtMember_email = (EditText) findViewById(R.id.edtMember_email);
        edtMember_name = (EditText) findViewById(R.id.edtMember_name);
        btnMember_OK = (Button) findViewById(R.id.btnMember_OK);

        InputFilter[] IDfilters = new InputFilter[]{filterID, lenghtID};
        InputFilter[] PWfilters = new InputFilter[]{filterPW, lenghtPW};
        InputFilter[] NAMEfilters = new InputFilter[]{filterName, lenghtName};

/*
* EditText정규화
* id - 영어와 숫자만 입력 가능,글자 제한 20
* pw - 한글만 제한, 글자 제한 12
* email - email 형식만 입력 가능
* name - 특수문자 제한, 글자제한 10*/
        edtMember_id.setFilters(IDfilters);
        edtMember_pw.setFilters(PWfilters);
//        edtMember_email.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        edtMember_name.setFilters(NAMEfilters);

        btnMember_OK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String result; //서버에서 받아온 값

                connectCheck();

                    try {
//                        //값 bundle에 넣고 서버로 보냄
//                        Bundle bundle = new Bundle();
//                        bundle.putSerializable("action", "member");
//                        bundle.putSerializable("username", edtMember_id.getText().toString());
//                        bundle.putSerializable("password", edtMember_pw.getText().toString());
//                        bundle.putSerializable("passwordConfirm", edtMember_pw_re.getText().toString());
//                        bundle.putSerializable("name", edtMember_name.getText().toString());
//                        bundle.putSerializable("email", edtMember_email.getText().toString());
//                        task = new HTTPAsuncTask(getApplicationContext(), bundle);
//                        result = task.execute().get(); //서버에서 값을 받아옴
                        Bundle data = new Bundle();
                        data.putString("action", "member");
                        data.putString("username", edtMember_id.getText().toString());
                        data.putString("password", edtMember_pw.getText().toString());
                        data.putString("passwordConfirm", edtMember_pw_re.getText().toString());
                        data.putString("name", edtMember_name.getText().toString());
                        data.putString("email", edtMember_email.getText().toString());

                        new ServerConnect(handler, data).start();

                        /*
                        * 성공 = 0,
                        * 서버 에러 = -1,
                        * 비밀번호 불일치 = -10
                        * */
//                        if (result.equals("0")) {
//                            //login 화면으로 이동
//                            startActivity(new Intent(getApplicationContext(), long.class));
//                            Toast.makeText(getApplicationContext(), "가입 완료", Toast.LENGTH_LONG);
//
//                        }else if(result.equals("-1")) {   // 가입x 토스트로 경고 보여줌
//                            Toast.makeText(getApplicationContext(), "server error, 다시 시도해 주세요", Toast.LENGTH_LONG);
//                        }
//                        else if(result.equals("-10")){  //비밀번호 EditText초기화, 가입x, 경고
//                            edtMember_pw.setText("");
//                            edtMember_pw_re.setText("");
//                            Toast.makeText(getApplicationContext(), "비밀번호가 일치하지 않습니다.", Toast.LENGTH_LONG);
//
//                        }
//                    } catch (InterruptedException e) {
//                        e.printStackTrace();
//                    } catch (ExecutionException e) {
//                        e.printStackTrace();
//                    }
                }
        });
    }


    protected void onPause() {
        super.onPause();
        if (task != null) {
            task.cancel(true);
            task = null;
        }
    }

    //네트워크 상태 확인
    public void connectCheck() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            //Toast.makeText(this,"네트워크 연결중입니다.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "네트워크 상태를 확인하십시오", Toast.LENGTH_SHORT).show();
        }
    }

    //id 정규화
    public InputFilter filterID= new InputFilter() {
        @Override
        public CharSequence filter(CharSequence charSequence, int start, int end, Spanned spanned, int dstart, int dend) {
            Pattern patternID = Pattern.compile("^[a-z A-Z 0-9]*$");
            if(!patternID.matcher(charSequence).matches()){
                return "";
            }
            return null;
        }
    };
    InputFilter lenghtID = new InputFilter.LengthFilter(20);


    //pw 정규화
    public InputFilter filterPW = new InputFilter() {
        @Override
        public CharSequence filter(CharSequence charSequence, int i, int i1, Spanned spanned, int i2, int i3) {
            Pattern patternPW = Pattern.compile("^[ㄱ-ㅣ가-힣]*$");
            if(patternPW.matcher(charSequence).matches()){
                return "";
            }
            return null;
        }
    };
    InputFilter lenghtPW = new InputFilter.LengthFilter(12);

    //name 정규화
    public InputFilter filterName = new InputFilter() {
        @Override
        public CharSequence filter(CharSequence charSequence, int i, int i1, Spanned spanned, int i2, int i3) {
            Pattern patternName = Pattern.compile("^[ㄱ-ㅣ가-힣 a-z A-Z]+$");
            if(!patternName.matcher(charSequence).matches()){
                return "";
            }
            return null;
        }
    };
    InputFilter lenghtName = new InputFilter.LengthFilter(10);


    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case ServerConnect.SEVER_SUCESS:

                    if (msg.what == ServerConnect.SEVER_SUCESS) {
                        Bundle data = msg.getData();
                        if (data.getInt("result") == 0) {
                            Toast.makeText(getApplicationContext(), "가입 완료", Toast.LENGTH_LONG);
//                            SharedPreferences preferences = getSharedPreferences("info", MODE_PRIVATE);
//                            SharedPreferences.Editor editor = preferences.edit();
//                            editor.putString("userid", edt_id.getText().toString());
//                            editor.commit();
                            Intent intent = new Intent(getApplicationContext(), login.class);
                            startActivity(intent);

                        } else if (data.getInt("result") == -10) {
                            Toast.makeText(getApplicationContext(), "비밀번호가 일치하지 않습니다.", Toast.LENGTH_LONG).show();
                        } else if (data.getInt("result") == -1) {
                            Toast.makeText(getApplicationContext(), "서버에러 입니다 다시 시도하여 주십시오.", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "서버에러 입니다 다시 시도하여 주십시오.", Toast.LENGTH_LONG).show();

                    }
            }
        }
    };
}


