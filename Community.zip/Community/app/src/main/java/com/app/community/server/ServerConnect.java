package com.app.community.server;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Enumeration;
import java.util.Properties;

/**
 * Created by lovely ssun on 2017-07-07.
 */

public class ServerConnect extends Thread{
    protected Message m_msg = new Message();
    protected Handler m_Handler;

    protected StringBuffer m_buffer;
    private InputStream requestData;
    private URL url;
    private HttpURLConnection conn;
    private DataOutputStream out;
    private BufferedReader buffer;
    private Bundle data;

    protected String URL = "http://172.30.1.18:8080/spring.server.app/user/";
    protected String action;
    private String TAG;

    public static final int SEVER_SUCESS = 1;
    public static final int SEVER_FAIL = 0;

    public ServerConnect(Handler handler, Bundle bundle){
        m_Handler = handler;
        action = bundle.getString("action");
        TAG = bundle.getString("TAG");
        this.data = bundle;
    }

    @Override
    public void run() {
        super.run();

        try {
            requestData = sendPostMessage(wrapData());

            if(requestData == null){
                data.clear();
                data = new Bundle();
                data.putInt("result", -1);

                m_msg = m_Handler.obtainMessage(SEVER_FAIL);
                m_msg.setData(data);
                m_Handler.sendMessage(m_msg);
                return;
            }

            buffer = new BufferedReader(new InputStreamReader(requestData));
            StringBuffer str = new StringBuffer();
            String s = null;
            while ((s = buffer.readLine()) != null) {
                str.append(s);
            }

            Log.e("전송받은 데이터 : ", str.toString());

            data.clear();
            data = new Bundle();

            jsonParser(str.toString());

            m_msg = m_Handler.obtainMessage(SEVER_SUCESS);
            m_msg.setData(data);
            m_Handler.sendMessage(m_msg);

        } catch (Exception e) {
            e.printStackTrace();
            data.putInt("result", -1);
            m_msg = m_Handler.obtainMessage(SEVER_FAIL);
            m_msg.setData(data);
            m_Handler.sendMessage(m_msg);
        }
    }

    private Properties wrapData() {
        Properties prop = new Properties();
        switch (action) {
            case "login":
                prop.setProperty("username", data.getString("username"));
                prop.setProperty("password", data.getString("password"));
                break;
            case "addmember":
                prop.setProperty("username", data.getString("username"));
                prop.setProperty("password", data.getString("password"));
                prop.setProperty("passwordConfirm", data.getString("passwordConfirm"));
                prop.setProperty("name", data.getString("name"));
                prop.setProperty("email", data.getString("email"));
                break;
            case "edtmember":
                prop.setProperty("username", data.getString("username"));
                prop.setProperty("password", data.getString("password"));
                prop.setProperty("email", data.getString("email"));
                break;
            case "infomember":
                prop.setProperty("username", data.getString("username"));
                prop.setProperty("password", data.getString("password"));
                break;
        }
        return prop;
    }

    private InputStream sendPostMessage(Properties prop) throws IOException, Exception {
        url = new URL(getURL());
        Log.i(TAG + " >> 서버 url!!!", url.toString());

        conn = (HttpURLConnection) url.openConnection();

        conn.setDoInput(true);
        conn.setDoOutput(true);
        conn.setUseCaches(false);
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(5000);
        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

        try {

            conn.connect();

            out = new DataOutputStream(conn.getOutputStream());
            out.writeBytes(encodingProp(prop));
            out.flush();


        } finally {
            if (out != null)
                out.close();
        }

        return conn.getInputStream();
    }

    private String getURL() {
        String serversideURL = null;
        switch (action) {
            case "login":
                serversideURL = "login.json";
                break;
            case "addmember":
                serversideURL = "insert.json";
                break;
            case "edtmember":
                serversideURL = "xx.json";
                break;
            case "infomember":
                serversideURL = "xx.json";
                break;
        }
        return URL + serversideURL;
    }

    private String encodingProp(Properties prop) {
        StringBuffer buffer = new StringBuffer();
        Enumeration names = prop.propertyNames();
        String name = null;

        while (names.hasMoreElements()) {
            name = names.nextElement().toString();
            buffer.append(URLEncoder.encode(name) + "=" + URLEncoder.encode(prop.getProperty(name)));
            if (names.hasMoreElements()) {
                buffer.append("&");
            }
        }

        Log.e(TAG + " >> Server에 전송할 데이터!!", buffer.toString());
        return buffer.toString();
    }

    private boolean disconnect() {
        try {
            if (buffer != null) {
                requestData.close();
                buffer.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    private void jsonParser(String result) {
        try {
            if (action.equals("login") || action.equals("addmember")) {
                JSONObject jsonObject = new JSONObject(result);
                data.putInt("result", jsonObject.getInt("result"));
            }
//            JSONObject jsonObject = new JSONObject(result);
//            String outJson = jsonObject.getString("my");
//            JSONArray jsonArray = new JSONArray(outJson);
//
//            JSONObject inJson = null;
//            System.out.println("1");
//            for(int i = 0; i < jsonArray.length(); i++){
//                inJson = jsonArray.getJSONObject(i);
//
//            }
//            System.out.println("array.length():" + jsonArray.length());
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}

