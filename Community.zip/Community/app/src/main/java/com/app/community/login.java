package com.app.community;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.app.community.server.HTTPAsuncTask;
import com.app.community.server.ServerConnect;



import java.util.concurrent.ExecutionException;

public class login extends Activity {
    HTTPAsuncTask task = null;

    EditText edt_id, edt_pw; //ID,PW
    Button btn_login;        //login버튼
    TextView tv_member;      //회원가입

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        //결합

        edt_id = (EditText) findViewById(R.id.edt_id);
        edt_pw = (EditText) findViewById(R.id.edt_pw);
        btn_login = (Button) findViewById(R.id.btn_login);
        tv_member = (TextView) findViewById(R.id.tv_member);

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                String result; //서버에서 받아온 값
//
//                    connectCheck();
//
//                try {
//                    //값 bundle에 넣고 서버로 보냄
//                    Bundle bundle = new Bundle();
//                    bundle.putSerializable("action", "login");
//                    bundle.putSerializable("username", edt_id.getText().toString());
//                    bundle.putSerializable("password", edt_pw.getText().toString());
//                    task = new HTTPAsuncTask(getApplicationContext(), bundle);
//                    result = task.execute("").get(); //서버에서 값을 받아옴
//
//                    if (result.equals("0")) { //아이디, 비번 모두 맞을 경우 저장
//                        SharedPreferences settings = getSharedPreferences("info", Activity.MODE_PRIVATE);
//                        SharedPreferences.Editor prefEditor = settings.edit();
//                        prefEditor.putString("userid", edt_id.getText().toString());   //id 저장
//                        prefEditor.commit();    //반영
//
//                        //Main 화면으로 이동
//                        startActivity(new Intent(getApplicationContext(), MainActivity.class));
//
//                    } else if(result.equals("-1")){   //server error, 경고
//
//                        Toast.makeText(getApplicationContext(), "로그인 실패, 데이터나 와이파이를 확인한 뒤 다시 시도해주세요", Toast.LENGTH_LONG);
//                    }else if(result.equals("-10")){
//                        //id존재x, 경고, 입력창 리셋
//                        Toast.makeText(getApplicationContext(), "아이디가 존재하지 않습니다.", Toast.LENGTH_LONG);
//                        edt_id.setText("");
//                        edt_pw.setText("");
//                    }else if(result.equals("-100")){
//                        //
//                        Toast.makeText(getApplicationContext(), "비밀번호가 맞지 않습니다.", Toast.LENGTH_LONG);
//                        edt_pw.setText("");
//                    }
//                }  catch (InterruptedException e) {
//                    e.printStackTrace();
//                } catch (ExecutionException e) {
//                    e.printStackTrace();
//                }

                Bundle data = new Bundle();
                data.putString("username", edt_id.getText().toString());
                data.putString("password", edt_pw.getText().toString());
                data.putString("action", "login");

                new ServerConnect(handler, data).start();
            }
        });

        tv_member.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Membership.class));
            }
        });
    }

    protected void onPause() {
        super.onPause();
        if (task != null) {
            task.cancel(true);
            task = null;
        }
    }

    //웹에서 데이터를 가져오기 전에 먼저 네트워크 상태부터 확인
    public void connectCheck() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            //Toast.makeText(this,"네트워크 연결중입니다.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "네트워크 상태를 확인하십시오", Toast.LENGTH_SHORT).show();
        }
    }

    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case ServerConnect.SEVER_SUCESS:

                    if (msg.what == ServerConnect.SEVER_SUCESS) {
                        Bundle data = msg.getData();
                        if (data.getInt("result") == 1) {

                            SharedPreferences preferences = getSharedPreferences("info", MODE_PRIVATE);
                            SharedPreferences.Editor editor = preferences.edit();
                            editor.putString("userid", edt_id.getText().toString());
                            editor.commit();

                            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                            startActivity(intent);

                        } else if (data.getInt("result") == -10) {
                            Toast.makeText(getApplicationContext(), "아이디 또는 비밀번호가 틀렸습니다.", Toast.LENGTH_LONG).show();
                            edt_id.setText("");
                            edt_pw.setText("");
                        } else if (data.getInt("result") == -1) {
                            Toast.makeText(getApplicationContext(), "서버에러 입니다 다시 시도하여 주십시오.", Toast.LENGTH_LONG).show();
                            edt_id.setText("");
                            edt_pw.setText("");
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "서버에러 입니다 다시 시도하여 주십시오.", Toast.LENGTH_LONG).show();
                        edt_id.setText("");
                        edt_pw.setText("");
                    }
            }
        }

    };
}