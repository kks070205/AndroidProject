package com.app.community;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.app.community.server.HTTPAsuncTask;

import java.util.concurrent.ExecutionException;

public class WritingActivity extends Activity
{
    HTTPAsuncTask task;
    Button btnUpdate_writing, btnDelete_writing;
    TextView tvTile_writing, tvWrite_writing;
    int regnum;
    String  title, contents, userid;
    LinearLayout llButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_writing);


        llButton = (LinearLayout)findViewById(R.id.llButton);
        btnUpdate_writing = (Button)findViewById(R.id.btnUpdate_writing) ;
        btnDelete_writing = (Button)findViewById(R.id.btnDelete_writing) ;

        tvTile_writing = (TextView)findViewById(R.id.tvTile_writing);
        tvWrite_writing = (TextView)findViewById(R.id.tvWrite_writing);

        //이전 액티비티에서 받은 값 가져오기
        Intent data = getIntent();
        regnum = data.getIntExtra("regnum", 0);
        userid = data.getStringExtra("userid");
        title = data.getStringExtra("title");
        contents = data.getStringExtra("contents");


        //세션 아이디와 이 게시물의 userid가 같을 때 버튼 보여줌
        if(getSharedPreferences("info", MODE_PRIVATE).getString("userid", "").equals("1234"))
            llButton.setVisibility(View.VISIBLE);
        else
            llButton.setVisibility(View.GONE);

        //TextView에 내용 set
        tvTile_writing.setText(title);
        tvWrite_writing.setText(contents);

        btnUpdate_writing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //수정 버튼 터치 시, 모든 값들 write에 set하고 write 액티비티로 이동
                Intent intent = new Intent(getApplicationContext(), WriteActivity.class);
                intent.putExtra("action", "update");
                intent.putExtra("regnum", regnum);
                intent.putExtra("title", title);
                intent.putExtra("contents", contents);

                startActivity(intent);
            }
        });

        btnDelete_writing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //삭제 버튼 터치 시, regnum 값 서버로 전송
                Bundle bundle = new Bundle();
                bundle.putSerializable("action", "delete");
                bundle.putSerializable("regnum", regnum);
                task = new HTTPAsuncTask(getApplicationContext(), bundle);

                //서버에게 1 받았을 때 액티비티 종료
                try {
                    if(task.execute("").get().trim().equals("1"))
                        finish();
                    else
                        Toast.makeText(getApplicationContext(), "삭제 실패", Toast.LENGTH_SHORT);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        if(task != null) {
            task.cancel(true);
            task = null;
        }
    }
}
