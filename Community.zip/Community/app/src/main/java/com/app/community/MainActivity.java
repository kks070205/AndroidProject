package com.app.community;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.app.community.ListView.DataObject;
import com.app.community.ListView.ListViewAdapter;
import com.app.community.server.HTTPAsuncTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class MainActivity extends Activity {
    HTTPAsuncTask task; //리스트뷰 가져올 때 사용

    //리스트뷰에 필요한 선언
    ListView lvMainList;    //listview 위젯
    ListViewAdapter mAdtList;   //어댑터뷰
    ArrayList<DataObject> mdataList;  //listview에 셋팅할 DO들


    @Override
    protected void onResume() {
        super.onResume();

        //list 초기화
        mdataList = null;
        mAdtList = null;
        mdataList = new ArrayList<DataObject>();
        mAdtList = new ListViewAdapter();

        //서버에 요청
        Bundle bundle = new Bundle();
        bundle.putSerializable("action", "whole");
        task = new HTTPAsuncTask(getApplicationContext(), bundle);
        try {
            jsonParser(task.execute("").get().trim());

            mAdtList.addItem(mdataList);
            mAdtList.notifyDataSetChanged();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }

        //list 갱신
        lvMainList.setAdapter(mAdtList);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //  tvResult = (TextView)findViewById(R.id.tvResult);

        //list 관련 결합
        mdataList = new ArrayList<DataObject>();
        mAdtList = new ListViewAdapter();
        lvMainList = (ListView) findViewById(R.id.lvMainList);




        //리스트 뷰 터치 시 리스너
        lvMainList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                DataObject dataObject = (DataObject) parent.getItemAtPosition(position);

                Intent intent = new Intent(getApplicationContext(), WritingActivity.class);

                intent.putExtra("regnum", dataObject.getRegnum());
                intent.putExtra("regtime", dataObject.getRegtime());
                intent.putExtra("title", dataObject.getTitle());
                intent.putExtra("contents", dataObject.getContent());
                intent.putExtra("userid", dataObject.getUserid());

                startActivity(intent);
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (task != null) {
            task.cancel(true);
            task = null;
        }

    }

    private void jsonParser(String result) {
        //mdataList.removeAll(mdataList);

        try {
            JSONObject jsonObject = new JSONObject(result);
            String outJson = jsonObject.getString("whole");
            JSONArray jsonArray = new JSONArray(outJson);

            DataObject dataObject = null;
            JSONObject inJson = null;
            System.out.println("1");
            for (int i = 0; i < jsonArray.length(); i++) {
                inJson = jsonArray.getJSONObject(i);
                dataObject = new DataObject();

                dataObject.setRegnum(inJson.getInt("regnum"));
                dataObject.setRegtime(inJson.getString("regtime"));
                dataObject.setTitle(inJson.getString("title"));
                dataObject.setContent(inJson.getString("contents"));
                dataObject.setUserid(inJson.getString("userid"));

                mdataList.add(dataObject);
            }

            System.out.println("array.length():" + jsonArray.length());
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
